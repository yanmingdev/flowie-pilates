# 本次 Node.js／Express 與完整替換驗證

日期：2026-11-18（Asia/Taipei）。Node 24.22.3、Express 4.22.3（原 lockfile 解析版本）、npm 11.9.0。未升級套件，沒有對正式 Supabase 寫入或執行 SQL，沒有 Git 推送或部署。

| 項目 | 實際結果 | 證據與限制 |
|---|---|---|
| 全新解壓安裝 | 通過，npm ci 788 packages | 從新 ZIP 解壓到獨立目錄，不複製舊專案程式、環境檔、依賴或 dist |
| 同一份 source 驗證 | 通過 | 獨立目錄的 backend/src、frontend/src、config、scripts、tests 與交付來源位元組相同 |
| TypeScript／Lint／Build | 通過 | 原工作目錄及全新解壓目錄都通過 npm run check |
| Node／Express | 通過 | createApp 建立獨立 app；Node server 能 listen；控制器只傳最小 service context |
| 後端測試 | 21／21 | 原有 API／env／service 契約，加 app 工廠、server 生命週期與 context 邊界 |
| 前端測試 | 15／15 | 首頁、URL、Provider 清理、圖片相容；jsdom，不冒稱實體裝置 |
| 架構檢查 | 129 程式檔、668 函式／回呼，0 issues | 含非執行頁面的 config／scripts／tests；SQL 函式另有說明 |
| 路由／樣式 | 68 個 API 路由保留，CSS 展開指紋一致 | 沒有藉機新增商業功能或重新設計頁面 |
| SQL 安裝序列 | 通過 | 隔離 PostgreSQL 相容引擎執行完整 01→02→03→04→05→06→07，16 表、6 示範場次、3 知識內容 |
| UID 範本安全 | 通過 | 未替換 03／04 占位文字時拒絕；以真實存在的本機 Auth fixture UID 替換後成功 |
| 交易／RLS smoke | 通過 | 預約扣堂、取消退堂、本人隔離、老師點名／課後建議與管理員範圍；模擬 Auth |
| 原生 PostgreSQL 並發 | 3 情境通過 | 4 人搶 1 席只成功 1 人；重送不重扣；2 場搶最後 1 堂只成功 1 場 |
| ER model | 16 public 表、126 欄、17 FK | 從實際執行 SQL 擷取；含 auth.users 外部關聯，PNG 已目視檢查、簽章與雜湊校驗 |
| 單獨啟動驗證 | 19 項通過 | Node 編譯後健康檢查與 SIGTERM exit 0、根 npm run dev、Vite 入口／模組／fallback，以及 11 組新舊資產 |
| 真實 Supabase／SMTP／完整 PostgREST | 本次未測 | 無正式帳號交易或寄信；不宣稱已上線 |
| 真正瀏覽器與實機 | 本次未重新驗證 | jsdom／HTTP 可用性不等於畫面與手機驗收 |

主要證據：express-check-output.log、express-concurrency-output.log、express-architecture-result.json、standalone-check-output.log、standalone-runtime-result.json。先前版本的驗證輸出仍保留作歷史紀錄，不混算本次結果。

SQL 差異：01、02、05、06、07 有效內容未變；03／04 僅把歷史環境 Auth UID 改成明確占位文字，前後指紋與原因保留在 sql-integrity-baseline.json。沒有 schema／交易變更，因此沿用既有遠端 DB 不需要重跑 SQL。從空白 Supabase 安裝時，依 supabase/sql/README_SQL.md 設定真正 Auth UID 並逐檔執行。

PNG、DOT、catalog 與 SQL 來源雜湊在 er-artifacts.json／schema-catalog.json；check:architecture 不需 Graphviz 即可驗證一致性。只有重新產生 PNG 才需 Graphviz dot。Supabase Auth 的完整內部表沒有在圖中虛構，僅列被參照的 auth.users.id。
